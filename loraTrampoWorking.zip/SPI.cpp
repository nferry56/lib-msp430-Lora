#include "SPI.h"
#include <msp430.h>


LoRaSPIClass::LoRaSPIClass()
{
    LoRaSPIClass(1, 2);
};

LoRaSPIClass::LoRaSPIClass(uint8_t cs_gpio, uint8_t usci_module)
{
    _cs_gpio = cs_gpio;
    _usci_module = usci_module;
};

void LoRaSPIClass::initSPI()
{
    //--- SPI pinOut Configuration ---//
    P5OUT  |= BIT3;                             // Set P1.5 HIGH (LoRa chip is selected)
    P5DIR  |= BIT3;                             // Set P1.5 as OUTPUT for CS
    P5SEL0 |= BIT0 + BIT1 + BIT2;               // P5.0 = MOSI, P5.1 = MISO, P5.2 = CLK,
    P5SEL1 &= ~(BIT0 + BIT1 + BIT2);            // P5.0 = MOSI, P5.1 = MISO, P5.2 = CLK

    //--- USCI module configuration for SPI transfert ---//
    UCB1CTLW0 = UCSWRST;                        // USCI UCB1 - configuration mode
    UCB1CTLW0|= UCMSB + UCMST + UCSYNC;         // SET SPI : 3-pin, 8-bit SPI master
    UCB1CTL1 |= UCSSEL_2;                       // Clock source Select
    UCB1BR0 = 2;                                // Clock divider by 1
    UCB1BR1 = 0;                                //
    UCB1CTLW0 &= ~UCSWRST;                      // USCI - SPI Activate
}

uint8_t LoRaSPIClass::readRegister(uint8_t address)
{
    return singleTransfer(address & 0x7f,0x00);
}

void LoRaSPIClass::writeRegister(uint8_t address, uint8_t value)
{
    singleTransfer(address | 0x80,value);
}

uint8_t LoRaSPIClass::singleTransfer(uint8_t address, uint8_t value)
{
    uint8_t response;

    P5OUT &= ~BIT3;                         // CS (NSS) LOW - Chip Select Lora Chip
    while (!(UCB1IFG & UCTXIFG));           // USCI_B0 TX buffer ready?
        UCB1TXBUF = address;                // Send address over SPI to Slave
    while (!(UCB1IFG & UCRXIFG));           // USCI_B0 RX Received?
        response = UCB1RXBUF;               // Store received data

    while (!(UCB1IFG & UCTXIFG));           // USCI_B0 TX buffer ready?
        UCB1TXBUF = value;                  // Send value over SPI to Slave
    while (!(UCB1IFG & UCRXIFG));           // USCI_B0 RX Received?
        response = UCB1RXBUF;
    P5OUT |= BIT3;                          // CS (NSS) HIGH - Release Lora Chip

    return response;
}
