#include <msp430.h> 
#include <stdint.h>
#include "tpl_os.h"
#include "LoRaWan.h"


//--- LORA ABP KEYS parameters----------------------------------------------------------------------------------------------//
// Network Session Key (MSB)
uint8_t NwkSkey[16] = { 0x01, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
// Application Session Key (MSB)
uint8_t AppSkey[16] = { 0x01, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
// Device Address (MSB)
uint8_t DevAddr[4] = { 0x11, 0x22, 0x33, 0x44 };
//--------------------------------------------------------------------------------------------------------------------------//

unsigned int temp = 0xFFFF;
unsigned int data = 0xFFFF;
LoRaWan LoraRadio;

/*-----------------------------------------------------------------------------
 * Hardware init and main
 */
#define OS_START_SEC_CODE
#include "tpl_memmap.h"

/*
 * init some I/Os of the board:
 * - red   LED1  on P1.0
 * - green LED2  on P1.1
 * - S1 user button on P5.6
 */
FUNC(void, OS_APPL_CODE) ioInit()
{
    WDTCTL = WDTPW | WDTHOLD;                   // Stop WatchDog timer

    // Configure GPIO
    P1OUT = 0; P1DIR = 0xFF;
    P2OUT = 0; P2DIR = 0xFF;
    P3OUT = 0; P3DIR = 0xFF;
    P4OUT = 0; P4DIR = 0xFF;
    P5OUT = 0; P5DIR = 0xFF;
    P6OUT = 0; P6DIR = 0xFF;
    P7OUT = 0; P7DIR = 0xFF;
    P8OUT = 0; P8DIR = 0xFF;

    PJOUT = 0;
    PJSEL0 = BIT4 | BIT5;                     // For XT1 - LFXT 32Khz Osc
    PJDIR = 0xFFFF;

    // Configure GPIO for pushbutton interrupt
    P5OUT |= BIT6;                            // Pull-up resistor on P5.6
    P5REN |= BIT6;                            // Select Pullup or pulldown resistor enabled
    P5DIR &= ~BIT6;                           // Set all but P5.6 to output direction
    P5IES = BIT6;                             // P5.6 high-to-low transition
    P5IFG = 0;                                // Clear all P1 interrupt flags
    P5IE = BIT6;                              // P5.6 interrupt enabled

    // LED configuration
    P1DIR |= BIT0;
    P1DIR |= BIT1;

    // Disable the GPIO power-on default high-impedance mode to activate
    // previously configured port settings
    PMMCTL0_H = PMMPW_H;                      // Unlock PMM registers
    PM5CTL0 &= ~LOCKLPM5;                     // Unlock I/O pins
    PMMCTL0_H = 0x00;                         // Lock PMM registers

    // FRAM 1 WaitState (16 Mhz)
    FRCTL0 = FRCTLPW | NWAITS0;

    // Setup XT1 crystal.Set the Master and SM (16 MHz) and ACLK (XT1)
    CSCTL0_H = CSKEY >> 8;                    // Unlock CS registers
    CSCTL1 = DCORSEL | DCOFSEL_4;                   // Set DCO to 16MHz
    CSCTL2 = SELA__LFXTCLK | SELS__DCOCLK | SELM__DCOCLK; // set ACLK = XT1; MCLK = SMCLK = DCO
    CSCTL3 = DIVA__1 | DIVS__1 | DIVM__1;     // Set all dividers
    CSCTL4 &= ~LFXTOFF;
    // Wait for the oscillator to settle
    do
    {
        CSCTL5 &= ~LFXTOFFG;                    // Clear XT1 fault flag
        SFRIFG1 &= ~OFIFG;
    }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
    CSCTL0_H = 0;                             // Lock CS registers

    // Initialize the shared reference module
    ADC12CTL0 &= ~ADC12ENC;
    REFCTL0 = 0;
    while(REFCTL0 & REFGENBUSY);              // If ref generator busy, WAIT
    REFCTL0 |= REFVSEL_1;                     // Enable internal 2.0V reference (avec Auto REF ON)

    // Initialize ADC12
    ADC12CTL0 &= ~ADC12ENC;                              // Disable ADC12 Conversion (Enable Config mode)
    ADC12CTL0 = ADC12SHT0_4 | ADC12MSC | ADC12ON;        // Set sample time 64 CLK
    ADC12CTL1 = ADC12SSEL_1| ADC12SHP | ADC12SHS_1 | ADC12CONSEQ_1;   // Enable Single Multiple Samples (ADC12SSEL_1 = ACLCK) (ADC12SHS_3 = Timer TB0-CCR1)
    ADC12CTL2 = ADC12PWRMD | ADC12RES__12BIT;            // ADC12PWRMD (save power mode) et 12 Bits ADC
    ADC12CTL3 = ADC12TCMAP | ADC12BATMAP;                // Enable temperature sensor & internal battery mapping
    ADC12MCTL0 = ADC12VRSEL_1 | ADC12INCH_31;            // ADC input ch A31 => Battery sense (ADC12VRSEL_1) sur REF
    ADC12MCTL1 = ADC12VRSEL_1 | ADC12INCH_30 | ADC12EOS; // ADC input ch A30 => Tempe sense (sur REF) | Fin de Sequence
    ADC12IER0 |= ADC12IE1;                               // Enable Interrupt
    ADC12CTL0 |= ADC12ENC;                               // Enable ADC12 Conversion (end - Config mode)

    // Setup Timer A0 - CCR1
    TA0CCR0 = 0x7FFF-1;                       // CCR0 fix la periode de répétition (ens. 4 secondes [0-16s] )
    TA0CCR1 = 0x7FFF-2;                       // Déclenchement de CCR1 à CCR0-1
    TA0CCTL1 = OUTMOD_3;                      // CCR1 set/reset mode
    TA0CTL = ID__4|TASSEL__ACLK|MC__UP|TACLR; // Source ACLK, Up-Mode, DIV=4
}

/*-----------------------------------------------------------------------------
 * task Main lora Function
 */
FUNC(int, OS_APPL_CODE) main(void)
{
  ioInit();

  // Start LoRa Radio
  LoraRadio.begin( _EU863, CH0, SF12BW125, 15, false);
  LoraRadio.sendData( 80, ((const unsigned char *)"START LORA\0"), 11 );
  P5IFG &= ~BIT6;   // Clear P5.6 IFG
  //LoraRadio.lora.CAD();

  StartOS(OSDEFAULTAPPMODE);
  return 0;
}

#define OS_STOP_SEC_CODE
#include "tpl_memmap.h"

/*-----------------------------------------------------------------------------
 * task blink
 */
#define APP_Task_blink_START_SEC_CODE
#include "tpl_memmap.h"

TASK(blink)
{
    if ( data <= 0xA00 ) {                        // Si Voltage < 2.5V => allumage led et LOW BAT Lora Message
         P1OUT |= BIT1;
         P1OUT |= BIT0;    // P1.0 LED = ON
         LoraRadio.sendData( 80, ((const unsigned char *)"LOW BAT\0"), 8 );
    }
    else
	   P1OUT ^= BIT1;      /* toggle green led */
	TerminateTask();
}

#define APP_Task_blink_STOP_SEC_CODE
#include "tpl_memmap.h"

/*-----------------------------------------------------------------------------
 * ISR button
 */
#define APP_ISR_buttonS1_START_SEC_CODE
#include "tpl_memmap.h"

ISR(buttonS1)
{
    P5IFG &= ~BIT6;   // Clear P5.6 IFG
    P1OUT |= BIT0;    // P1.0 LED = ON

    LoraRadio.sendData( 80, ((const unsigned char *)"0123456789\0"), 11 );

    P1OUT &= ~BIT0;    // P1.0 LED = OFF
    //__bic_SR_register_on_exit(LPM0_bits);     // Exit LPM0
}

#define APP_ISR_buttonS1_STOP_SEC_CODE
#include "tpl_memmap.h"

/*-----------------------------------------------------------------------------
 * ISR adcreadDone
 */
#define APP_ISR_handler_adc_end_conversion_START_SEC_CODE
#include "tpl_memmap.h"

ISR(handler_adc_end_conversion)
{
  switch(ADC12IV)
  {
    case ADC12IV_ADC12IFG1:
        ADC12CTL0 &= ~ADC12ENC;                     // Disable ADC12-ENC (car single-multiple-channels) (force REF OFF also!)

        data = ADC12MEM1;                           // Flush IFG_MEM1
        data = ADC12MEM0;                           // Flush IFG_MEM0

        ADC12CTL0 |= ADC12ENC;                   // Restart ADC12 (single-multiple-channels for next Timer Trigger)
        break;        // Vector 16:  ADC12MEM0
    default: break;
  }
}

#define APP_ISR_handler_adc_end_conversion_STOP_SEC_CODE
#include "tpl_memmap.h"
