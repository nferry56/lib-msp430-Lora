#include <msp430.h> 
#include <stdint.h>
#include "tpl_os.h"
#include "LoRaWan.h"


//--- LORA ABP KEYS parameters----------------------------------------------------------------------------------------------//
// Network Session Key (MSB)
uint8_t NwkSkey[16] = { 0x01, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
// Application Session Key (MSB)
uint8_t AppSkey[16] = { 0x01, 0x02, 0x03, 0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
// Device Address (MSB)
uint8_t DevAddr[4] = { 0x11, 0x22, 0x33, 0x44 };
//--------------------------------------------------------------------------------------------------------------------------//

LoRaWan LoraRadio;

/*-----------------------------------------------------------------------------
 * Hardware init and main
 */
#define OS_START_SEC_CODE
#include "tpl_memmap.h"

/*
 * init some I/Os of the board:
 * - red   LED1  on P1.0
 * - green LED2  on P1.1
 * - S1 user button on P5.6
 */
FUNC(void, OS_APPL_CODE) ioInit()
{
    WDTCTL = WDTPW | WDTHOLD;                   // Stop WatchDog timer

    // Configure GPIO
    P1OUT = 0; P1DIR = 0xFF;
    P2OUT = 0; P2DIR = 0xFF;
    P3OUT = 0; P3DIR = 0xFF;
    P4OUT = 0; P4DIR = 0xFF;
    P5OUT = 0; P5DIR = 0xFF;
    P6OUT = 0; P6DIR = 0xFF;
    P7OUT = 0; P7DIR = 0xFF;
    P8OUT = 0; P8DIR = 0xFF;

    PJOUT = 0;
    PJSEL0 = BIT4 | BIT5;                     // For XT1 - LFXT 32Khz Osc
    PJDIR = 0xFFFF;

    // Configure GPIO for pushbutton interrupt
    P5OUT |= BIT6;                            // Pull-up resistor on P5.6
    P5REN |= BIT6;                            // Select Pullup or pulldown resistor enabled
    P5DIR &= ~BIT6;                           // Set all but P5.6 to output direction
    P5IES = BIT6;                             // P5.6 high-to-low transition
    P5IFG = 0;                                // Clear all P1 interrupt flags
    P5IE = BIT6;                              // P5.6 interrupt enabled

    // LED configuration
    P1DIR |= BIT0;
    P1DIR |= BIT1;

    PMMCTL0_H = PMMPW_H;                      // Unlock PMM registers
    PM5CTL0 &= ~LOCKLPM5;                     // Unlock I/O pins
    PMMCTL0_H = 0x00;                         // Lock PMM registers
}

/*-----------------------------------------------------------------------------
 * task Main lora Function
 */
FUNC(int, OS_APPL_CODE) main(void)
{
  ioInit();

  // Start LoRa Radio
  LoraRadio.begin( _EU863, CH0, SF12BW125, 15, false);
  LoraRadio.sendData( 80, ((const unsigned char *)"START LORA\0"), 11 );
  //LoraRadio.lora.CAD();

  StartOS(OSDEFAULTAPPMODE);
  return 0;
}

#define OS_STOP_SEC_CODE
#include "tpl_memmap.h"

/*-----------------------------------------------------------------------------
 * task blink
 */
#define APP_Task_blink_START_SEC_CODE
#include "tpl_memmap.h"

TASK(blink)
{
	P1OUT ^= BIT1;      /* toggle green led */
	TerminateTask();
}

#define APP_Task_blink_STOP_SEC_CODE
#include "tpl_memmap.h"

/*-----------------------------------------------------------------------------
 * ISR button
 */
#define APP_ISR_buttonS1_START_SEC_CODE
#include "tpl_memmap.h"

ISR(buttonS1)
{
    P5IFG &= ~BIT6;   // Clear P5.6 IFG
    P1OUT |= BIT0;    // P1.0 LED = ON

    LoraRadio.sendData( 80, ((const unsigned char *)"0123456789"), 11 );

    P1OUT &= ~BIT0;    // P1.0 LED = OFF
    //__bic_SR_register_on_exit(LPM0_bits);     // Exit LPM0
}

#define APP_ISR_buttonS1_STOP_SEC_CODE
#include "tpl_memmap.h"
